package com.example.wgclient

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File

/** Управляет единственным туннелем WireGuard. */
object VpnController {

    private var backend: GoBackend? = null

    private val _state = MutableStateFlow(Tunnel.State.DOWN)
    val state: StateFlow<Tunnel.State> = _state

    private val tunnel = object : Tunnel {
        override fun getName(): String = "wgclient"
        override fun onStateChange(newState: Tunnel.State) {
            _state.value = newState
        }
    }

    private fun backend(context: Context): GoBackend =
        backend ?: GoBackend(context.applicationContext).also { backend = it }

    /** Бросает исключение, если конфиг некорректен или туннель не поднялся. */
    suspend fun connect(context: Context, configText: String) = withContext(Dispatchers.IO) {
        val config = Config.parse(configText.byteInputStream())
        backend(context).setState(tunnel, Tunnel.State.UP, config)
    }

    suspend fun disconnect(context: Context) = withContext(Dispatchers.IO) {
        backend(context).setState(tunnel, Tunnel.State.DOWN, null)
    }

    // Конфиг хранится в приватной папке приложения (недоступна другим приложениям).
    private fun file(context: Context) = File(context.filesDir, "tunnel.conf")

    fun loadConfig(context: Context): String =
        file(context).takeIf { it.exists() }?.readText().orEmpty()

    fun saveConfig(context: Context, text: String) {
        file(context).writeText(text)
    }
}
