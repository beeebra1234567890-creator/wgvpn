package com.example.wgclient

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { VpnScreen() }
            }
        }
    }
}

@Composable
private fun VpnScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by VpnController.state.collectAsState()

    var configText by remember { mutableStateOf(VpnController.loadConfig(context)) }
    var message by remember { mutableStateOf("") }

    fun connect() {
        scope.launch {
            try {
                VpnController.saveConfig(context, configText)
                VpnController.connect(context, configText)
                message = ""
            } catch (e: Exception) {
                message = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    // Системный диалог «Разрешить VPN-подключение»
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) connect()
        else message = "Разрешение на VPN не выдано"
    }

    // Импорт .conf файла
    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching { readText(context, uri) }
                .onSuccess { configText = it; message = "" }
                .onFailure { message = "Не удалось прочитать файл" }
        }
    }

    val isUp = state == Tunnel.State.UP

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("WG VPN", style = MaterialTheme.typography.headlineMedium)

        Text(
            if (isUp) "Подключено" else "Отключено",
            style = MaterialTheme.typography.titleLarge,
            color = if (isUp) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )

        Button(
            onClick = {
                if (isUp) {
                    scope.launch {
                        runCatching { VpnController.disconnect(context) }
                            .onFailure { message = "Ошибка: ${it.message}" }
                    }
                } else if (configText.isBlank()) {
                    message = "Вставьте или импортируйте конфиг"
                } else {
                    val intent = GoBackend.VpnService.prepare(context)
                    if (intent != null) permissionLauncher.launch(intent) else connect()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = if (isUp) ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.error
            ) else ButtonDefaults.buttonColors()
        ) {
            Text(if (isUp) "Отключить" else "Подключить")
        }

        if (message.isNotEmpty()) {
            Text(message, color = MaterialTheme.colorScheme.error)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { filePicker.launch(arrayOf("*/*")) }) {
                Text("Импорт .conf")
            }
            OutlinedButton(onClick = { configText = ""; message = "" }) {
                Text("Очистить")
            }
        }

        OutlinedTextField(
            value = configText,
            onValueChange = { configText = it },
            label = { Text("Конфиг WireGuard") },
            placeholder = { Text("[Interface]\nPrivateKey = ...\nAddress = ...\n\n[Peer]\nPublicKey = ...\nEndpoint = ...\nAllowedIPs = 0.0.0.0/0") },
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            modifier = Modifier.fillMaxWidth(),
            minLines = 10
        )
    }
}

private fun readText(context: Context, uri: Uri): String =
    context.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
